<template>
  <n-h3><strong>{{ buyerName }}</strong></n-h3>
  
  <n-space style="width: 100%; max-height: 400px; overflow-y: auto; overflow-x: auto; display: flex; flex-direction: column;" justify="start" align="stretch">
    <n-table class="fixTableHead" size="small">
      <thead>
        <tr>
          <th>Product</th>
          <th>Qty.</th>
          <th>Pk.Sz</th>
          <th>Comments</th>
        </tr>
      </thead>
      <tbody>
        <tr style="cursor: pointer" v-for="(qi, idx) in enqitems" :key="'qi-' + idx">
          <td>
            {{ qi?.productname }}
          </td>
          <td>{{ qi?.quantity }}</td>
          <td>{{ qi?.quote_pack_size }}</td>
          <td>{{ qi?.comments }}</td>
        </tr>
      </tbody>
    </n-table>
    <n-table class="fixTableHead" :style="{ 'border': dq.isselected ? '2px solid green' : 'none' }" @click="selectSeller(dq)" size="small"
      v-for="(dq, i) in data" :key="'dq' + i">
      <thead>
        <tr>
          <th>
            <n-space>
              <div>{{ dq?.seller }}</div>
              <div>{{enquiry.currency_option}} ({{ dq?.total_price }})</div>
              <n-rate size="small" v-model:value="dq.sellerrating" :allow-half="true" :readonly="true"></n-rate>
            </n-space>
          </th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(dqi, j) in dq.quotation_items">
          <td :style="{ background: dqi.isselected ? 'lightgreen' : 'initial' }"> (Qty-{{dqi?.quantity}}
           Pk-{{ dqi?.pack_size }} UP-{{ dqi?.unit_price }} TP-{{ enquiry.currency_option }}({{dqi?.totalprice }})  ExD-{{ dqi?.expiry?.toLocaleDateString() }} FOC-{{ dqi?.foc }} SC-{{dqi?.comments }}  )</td>
        </tr>
      </tbody>
    </n-table>
  </n-space>
  <n-space v-if="can_create_po" justify="end">
    <n-button style="float: right; margin-top: 1rem" v-if="enquiry && enquiry.status != 'PO_RAISED'" type="tertiary"
      @click="selectLeastItemQuotedSellers">Select sellers with least quoted Price Per Product</n-button>
    <n-button style="float: right; margin-top: 1rem" v-if="enquiry && enquiry.status != 'PO_RAISED'" type="tertiary"
      @click="selectLeastTotalQuotedSellers">Select Least Quoted Seller</n-button>
    <n-button style="float: right; margin-top: 1rem" v-if="enquiry && enquiry.status != 'PO_RAISED'" type="primary"
      @click="() => { raisePO(); $emit('close') }" :disabled="!selectedSellers || !selectedSellers?.length">RAISE
      PO</n-button>
  </n-space>
</template>

<script lang="ts" setup>
import { onMounted, onActivated, ref } from "vue";
import {
  type DataTableColumns,
  useMessage,
  useDialog,
  NButton,
  NDataTable,
  NSpace,
} from "naive-ui";
import type { Result } from "@/composables/request";
import { Icon } from "@/components";
import { useRouter } from "vue-router";

import { set } from "@/utils/storage";
import {
  AddPO,
  GetAllProducts,
  GetEnquiries,
  GetProducts,
  GetProductsForBuyer,
  GetProductsForSeller,
  GetQuotations,
} from "@/services/workflowsvc";
import type { BaseListResponse } from "@/models/BaseResponse";
import {
  EnquiryItem,
  PageRequest,
  POEnquiryItem,
  Product,
  PurchaseOrderItem,
  Quotation,
  Role,
  SellerOrg,
  type BuyerOrg,
  type Enquiry,
  type User,
} from "@/models/Workflow";
import { GetBuyers, GetSellers, GetRoles } from "@/services/mastersvc";
import { get } from "../../utils/storage";
import { defineComponent } from 'vue'
import { DEnquiryItem, DQuotation, DQuotationItem } from "@/models/Display";

const router = useRouter();

let loadingRef = ref(false);

const message = useMessage();

const props = defineProps(["enquiry", "sellerorg"]);

const allquotations = ref<DQuotationItem[]>();
const selectedSellers = ref<DQuotation[]>();
const enqitems = ref<DEnquiryItem[]>();
const data = ref<DQuotation[]>();
let buyers = ref<BuyerOrg[]>();
let sellers = ref<SellerOrg[]>();
let products = ref<Product[]>();
const dialog = useDialog();

const can_create_po = ref(false);
const buyerName = ref('');
onMounted(async () => {
  await loadData();
  let permissions = get('permissions');
  if (!permissions) permissions = [];
  can_create_po.value = permissions.includes('create-po');
   
});
onActivated(async () => { });
//init data
const loadData = async (currentPage: number = 1) => {
  try {
    let user = get('user');
    let perms = get('permissions');
    let isseller = perms && perms.includes('create-quotation');
    let isbuyer = perms && perms.includes('create-po');

    let sorgs = user && user.seller_orgs ? user.seller_orgs : [];
    if (!isbuyer && (!sorgs || !sorgs.length)) {
      message.error("No valid seller org mapped to the user");
      return;
    }
    if (isseller) {
      const sellerId = sorgs[0];
      let rresp: Result<BaseListResponse<Product>> = await GetAllProducts({ seller_org_id: sellerId });
      if (rresp && rresp.data) {
        products.value = rresp.data.value?.items;
      }
    }
    if (isbuyer) {
      let borgs = user && user.buyer_orgs ? user.buyer_orgs : [];
      if (!borgs || !borgs.length) {
        message.error("No valid buyer org mapped to the user");
        return;
      }
      const buyerId = borgs[0];

      let tresp: Result<BaseListResponse<Product>> = await GetProductsForBuyer({ buyer_org_id: buyerId });
      if (tresp && tresp.data) {
        products.value = tresp.data.value?.items;
      }
    }
    enqitems.value = [];
    for (let i = 0; i < props.enquiry.enquiry_items?.length; i++) {
      let eqi = props.enquiry.enquiry_items[i];
      let deqi = new DEnquiryItem();
      deqi = Object.assign(deqi, eqi);
      let prod = products.value?.find((x) => x._id == deqi.product_id);
      deqi.productname = prod?.name;
      enqitems.value.push(deqi);
    }

    let bresp: Result<BaseListResponse<BuyerOrg>> = await GetBuyers();
    if (bresp && bresp.data) {
      buyers.value = bresp.data.value?.items;
    }
    let sresp: Result<BaseListResponse<SellerOrg>> = await GetSellers();
    if (sresp && sresp.data) {
      sellers.value = sresp.data.value?.items;
    }

    buyerName.value = buyers.value[0].name;
    console.log('Buyer Name is ', buyerName);

    let quotes = props.enquiry.quotations.filter(x => x.status == "FINALISED"); //todo
    if (isseller) {
      quotes = props.enquiry.quotations.filter(x => x.seller_org_id == sorgs[0] && x.status == "FINALISED");
    }
    let dquotes = [];
    quotes.forEach((quote) => {
      let dquote = new DQuotation();
      dquote.comments = quote.comments;
      let buyer = buyers.value.find((x) => x._id == quote.buyer_org_id);
      let seller = sellers.value.find((x) => x._id == quote.seller_org_id);
      dquote.buyer = buyer?.name;
      dquote.seller = seller?.name;
      dquote.sellerrating = 2.0;
      dquote.enquiry_id = quote.enquiry_id;
      dquote._ct = quote._ct;
      dquote.currency = quote.currency;
      dquote.quotation_items = [];
      let totalprice = quote.quotation_items
        ?.map((x) => x.total_price)
        .reduce((p: number, c: number) => p + c, 0);
      dquote.total_price = totalprice;
      dquote.sellerrating = seller?.rating;
      quote.quotation_items?.forEach((qi) => {
        let dqi = new DQuotationItem();
        dqi.enquiry_item_id = qi.enquiry_item;
        dqi.seller_org_id = quote.seller_org_id;
        dqi.comments = qi.comments;
        dqi.currency = qi.currency;
        dqi.unit_price = qi.unit_price;
        dqi.totalprice = qi.total_price;
        dqi.pack_size = qi.pack_size;
        dqi.quantity = qi.quantity;
        dqi.foc = qi.foc;
        dqi.expiry = qi.expiry ? new Date(qi.expiry) : qi.expiry;
        
        
        let ei = props.enquiry.enquiry_items?.find((x) => x._id == qi.enquiry_item);

        let prod = products.value.find((x) => x._id == ei.product_id);
        dqi.productname = prod?.name;
        dqi.product_id = prod?._id;
        dqi.seller = dquote.seller;
        dqi.sellerrating = dquote.sellerrating;
        dquote.quotation_items?.push(dqi);
      });
      dquotes.push(dquote);
    });
    data.value = dquotes;
    console.log(dquotes);

    allquotations.value = data.value.map((x) => x.quotation_items).reduce((p, c) => p?.concat(c), []);
  } catch (ex) { }
  // const delay = (ms: number) => new Promise((res) => setTimeout(res, ms));
  // await delay(3000);
  loadingRef.value = false;
};

const selectSeller = async (seller: DQuotation) => {
  data.value?.forEach(element => {
    element.isselected = false;
  });
  selectedSellers.value = [];
  selectedSellers.value.push(seller);
  seller.isselected = true;
}

const selectLeastItemQuotedSellers = async () => {
  data.value?.forEach(element => {
    element.isselected = false;
  });
  selectedSellers.value = [];
  enqitems.value?.forEach(eqi => {
    let leastquote = -1;
    let leastitemquoteseller = null;
    let leastquoteditem = null;
    for (let i = 0; i < data.value?.length; i++) {
    let quote = data.value[i];
    let qi = quote.quotation_items?.find(x => x.enquiry_item_id == eqi._id);
    if (qi?.totalprice > 0 && (leastquote == -1 || (qi?.totalprice < leastquote))) {
        leastitemquoteseller = quote;
        leastquote = qi?.totalprice;
        leastquoteditem = qi;
      }
    }
    if (leastquoteditem) {
      leastquoteditem.isselected = true;
      if (!selectedSellers.value?.includes(leastitemquoteseller)) {
        leastitemquoteseller.isselected = true;
        selectedSellers.value.push(leastitemquoteseller);
      }
    }
  });
};

const selectLeastTotalQuotedSellers = async () => {
  data.value?.forEach(element => {
    element.isselected = false;
  });
  selectedSellers.value = [];

  let leastquotedseller = null;
  let leastquoteval = -1;
  for (let i = 0; i < data.value?.length; i++) {
    let quote = data.value[i];
    quote.quotation_items?.forEach(x => x.isselected = false);
    if (quote?.total_price > 0 &&( leastquoteval == -1 || quote?.total_price < leastquoteval)) {
      leastquotedseller = quote;
      leastquoteval = quote.total_price;
    }
  }
  leastquotedseller.isselected = true;
  selectedSellers.value.push(leastquotedseller);
};

const raisePO = async () => {
  await raiseOrder();

};

const raiseOrder = async () => {
  let poitems: PurchaseOrderItem[] = [];
  let allproditems = selectedSellers.value?.map((x) => x.quotation_items)
    .reduce((p, c) => p?.concat(c), []);
  if (selectedSellers.value?.length > 1) {
    allproditems = allproditems?.filter(x => x.isselected);
  }
  for (let i = 0; i < allproditems.length; i++) {
    let pdisp = allproditems[i];
    let poitem = poitems.find(x => x.seller_org_id == pdisp.seller_org_id);
    let eqi = new POEnquiryItem();
    eqi.product_id = pdisp.product_id;
    eqi.quantity = pdisp.quantity;
    eqi.quote_unit_price = pdisp.unit_price;
    eqi.quote_pack_size = pdisp.pack_size;
    eqi.enquiry_item_id = pdisp.enquiry_item_id;
    eqi.quote_total_price = pdisp.totalprice;
    if (!poitem) {
      poitem = new PurchaseOrderItem();
      // poitem._id = pdisp.poid;
      poitem.buyer_org_id = props.enquiry.buyer_org_id;
      poitem.enquiry_id = props.enquiry._id;
      poitem.seller_org_id = pdisp.seller_org_id;
      poitems.push(poitem);
    }
    if (!poitem.enquiry_items) poitem.enquiry_items = [];
    poitem.enquiry_items?.push(eqi);
  }
  console.log(poitems);
  await AddPO(poitems);
  message.success("Purchase raised successfully");
  // close the dialog box by updating status
}
</script>
<style>
.fixTableHead {
  overflow-y: auto;
  height: 110px;
}
.fixTableHead thead th {
  position: sticky;
  top: 0;
}

table {
  border-collapse: collapse;        
  width: 100%;
}
th,
td {
  padding: 8px 15px;
  border: 2px solid #529432;
}
th {
  background: #ABDD93;
}
tr>th:first-child,tr>td:first-child {
    position: sticky;
    left: 0;
  }

</style>
